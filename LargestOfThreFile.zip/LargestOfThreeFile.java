/**
 * Created by Genesis on 2/14/2016.
 */
import jdk.nashorn.internal.ir.WhileNode;

import java.util.Scanner;
import java.io.*;


public class LargestOfThreeFile {
    public static void main(String[] args) throws IOException {
        //variables
        double num1 = 0, num2 = 0, num3 = 0, largestNum;


        //scanner object
        Scanner keyboard = new Scanner(System.in);

        //get the file name
        System.out.print("Enter the file name: ");
        String filename = keyboard.nextLine();

        //open file
        File file = new File(filename);
        Scanner inputFile = new Scanner(file);

        System.out.print("the numbers are: ");

        //read all values
        while (inputFile.hasNext()) {
            String number = inputFile.nextLine();


            //read a value

            System.out.print(" " + number);
            }



        for (int i = 1; i <= 3; i++)

            if (i == 1)
                num1 = num1 + inputFile.nextDouble();

            else if (i == 2)
                num2 = num2 + inputFile.nextDouble();

            else if (i == 3)
                num3 = num3 + inputFile.nextDouble();

            else
                if (num1 >= num2)
                    if (num1 >= num3)
                        largestNum = num1;

                if (num2 >= num3)
                    largestNum = num2;

                else
                    largestNum = num3;




        System.out.print("The largest number is: " +
        largestNum + " .");


        int reps = 1;
        while (reps <= 10) ;
        System.out.println(largestNum);
        reps++;
        inputFile.close();
    }
}





